

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web-development\kantong-medis\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>