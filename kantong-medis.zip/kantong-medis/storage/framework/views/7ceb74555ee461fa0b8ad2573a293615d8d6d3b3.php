<div class="container py-4">
    <div class="row mb-4">
        <div class="col">
            <input wire:model="search" class="form-control" type="search" placeholder="Search">
        </div>
    </div>
    <div class="row">
        <div class="col-3">
            <div class="card">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item" style="font-weight: 600;">Filter Pencarian Anda</li>
                    <li class="list-group-item">
                        

                        
                        <div class="mb-2">Partner Kami</div>
                        <select wire:model="partner" class="form-select mb-2">
                            <option value="">Select</option>
                            <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </li>
                </ul>
            </div>
        </div>
        <div class="col-9">
            <div class="row explore">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="row mb-3 align-items-center">
                                    <div class="col-2">
                                        <img src="<?php echo e(asset('storage/' . $row->partner->image)); ?>" alt=""
                                            style="width: 100%" />
                                    </div>
                                    <div class="col-10">
                                        <span class="h5 card-title"><?php echo e($row->name); ?></span>
                                        <br>
                                        <span
                                            class="card-subtitle text-primary"><?php echo e($row->category->service_name); ?></span>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <p class="card-text">Stok : <?php echo e($row->stock); ?></p>
                                        <p class="card-text">
                                            <i class="bi bi-house-door text-secondary"></i> <?php echo e($row->partner->name); ?>

                                            <br>
                                            <i class="bi bi-geo-alt text-secondary"></i> <?php echo e($row->partner->address); ?>

                                            <br>
                                            <i class="bi bi-phone text-secondary"></i> <?php echo e($row->partner->phone); ?>

                                        </p>
                                        <p class="card-text text-danger fs-6 fst-italic">*<?php echo e($row->note); ?></p>
                                        <a href="<?php echo e($row->partner->map); ?>" class="btn btn-outline-danger">
                                            <i class="bi bi-map"></i> Map
                                        </a>
                                        <a href=" https://wa.me/<?php echo e($row->partner->phone); ?>"
                                            class="btn btn-outline-success">
                                            <i class="bi bi-whatsapp"></i> Whatsapp
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer text-muted bg-white">
                                <?php echo e($row->updated_at->diffForHumans()); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\web-development\kantong-medis\resources\views/livewire/explore/index.blade.php ENDPATH**/ ?>