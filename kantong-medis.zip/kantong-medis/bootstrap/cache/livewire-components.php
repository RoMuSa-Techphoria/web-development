<?php return array (
  'explore.index' => 'App\\Http\\Livewire\\Explore\\Index',
);